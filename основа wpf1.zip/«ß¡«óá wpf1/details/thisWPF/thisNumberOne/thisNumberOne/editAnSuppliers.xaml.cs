﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для editAnSuppliers.xaml
    /// </summary>
    public partial class editAnSuppliers : Page
    {
        public suppliers _tempSuppliers = new suppliers();
        public editAnSuppliers(suppliers suppliers)
        {
            InitializeComponent();
            _tempSuppliers = suppliers;
            firmView.Text = suppliers.suppliers_title;
            phoneView.Text = suppliers.suppliers_phone;
            adressView.Text = suppliers.suppliers_adress;
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(customerVerification.CheckEmptySupp(firmView.Text, adressView.Text, phoneView.Text))
                {
                    _tempSuppliers.suppliers_title = firmView.Text;
                    _tempSuppliers.suppliers_phone = phoneView.Text;
                    _tempSuppliers.suppliers_adress = adressView.Text;
                }
                DatabaseControl.UpdateClientsuppliers(_tempSuppliers);
                this.Content = null;
            }
            catch
            {
                MessageBox.Show("Ошибка данных при вводе", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
