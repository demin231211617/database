﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для addAnClient.xaml
    /// </summary>
    public partial class addAnClient : Page
    {
        public addAnClient()
        {
            InitializeComponent();
        }


        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            client _tempClient = new client();
            try
            {
                if(customerVerification.CheckEmpty(fioView.Text, phoneView.Text, adressView.Text)){
                    _tempClient.client_fio = fioView.Text;
                    _tempClient.client_phone = phoneView.Text;
                    _tempClient.client_adress = adressView.Text;
                    DatabaseControl.AddClient(new client
                    {
                        client_fio = fioView.Text,
                        client_phone = phoneView.Text,
                        client_adress = adressView.Text
                    });
                    daf.Content = new User();
                }
            }
            catch
            {
                MessageBox.Show("Ошибка при вводе");
            }
        }
    }
}
