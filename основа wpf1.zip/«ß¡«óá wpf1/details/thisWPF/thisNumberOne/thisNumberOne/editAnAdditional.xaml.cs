﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для editAnAdditional.xaml
    /// </summary>
    public partial class editAnAdditional : Page
    {
        public job _tempJob = new job();
        public editAnAdditional(job job)
        {
            InitializeComponent();
            _tempJob = job;
            jobView.Text = job.title_job;
            opisView.Text = job.job_description;
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if(customerVerification.CheckEmptyJob(jobView.Text, opisView.Text))
                {
                    _tempJob.title_job = jobView.Text;
                    _tempJob.job_description = opisView.Text;
                }
                DatabaseControl.UpdateJob(_tempJob);
                gaf.Content = new AdditionalInformation();
            }
            catch
            {
                MessageBox.Show("Ошибка данных при вводе", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
