﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.NewFolder1;

namespace thisNumberOne.FolderPenColor
{
    /// <summary>
    /// Логика взаимодействия для penColor.xaml
    /// </summary>
    public partial class penColor : Page
    {
        public penColor()
        {
            InitializeComponent();
            penColors.ItemsSource = DatabaseControl.GetPenColorForView();
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            pen_color p = penColors.SelectedItem as pen_color;
            if (p != null)
            {
                ret.Content = new editPenColor(p);
            }
            else
                MessageBox.Show("Выберите элемент для изменения", "Ошибка при выборе объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            pen_color p = penColors.SelectedItem as pen_color;
            if (p != null)
            {
                DatabaseControl.DelPenColor(penColors.SelectedItem as pen_color);
                penColors.ItemsSource = null;
                penColors.ItemsSource = DatabaseControl.GetPenColorForView();
            }
            else
                MessageBox.Show("Выберите элемент для удаления", "Ошибка при удалении объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            ret.Content = new addPenColor();
        }
    }
}
