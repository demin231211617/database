﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne.FolderPenColor
{
    public class pen_color
    {
        [Key]public int pen_color_id { get; set; }
        public string pen_color_title { get; set; }
    }
}
