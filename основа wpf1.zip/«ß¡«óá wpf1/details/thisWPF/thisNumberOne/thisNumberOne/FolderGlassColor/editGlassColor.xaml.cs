﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using thisNumberOne.FolderPenColor;

namespace thisNumberOne.FolderGlassColor
{
    /// <summary>
    /// Логика взаимодействия для editGlassColor.xaml
    /// </summary>
    public partial class editGlassColor : Page
    {
        public glass_color _glass_color = new glass_color();

        public editGlassColor(glass_color glass_color)
        {
            InitializeComponent();
            _glass_color = glass_color;
            fioView.Text = _glass_color.glass_color_title;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            _glass_color.glass_color_title = fioView.Text;
            DatabaseControl.UpdateGlassColor(_glass_color);
            gaf.Content = new glassColor();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }
    }
}
