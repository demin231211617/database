﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для addAnAdditional.xaml
    /// </summary>
    public partial class addAnAdditional : Page
    {
        public addAnAdditional()
        {
            InitializeComponent();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            job _tempJob = new job();
            try
            {
                if(customerVerification.CheckEmptyJob(jobView.Text, opisView.Text)){
                    _tempJob.title_job = jobView.Text;
                    _tempJob.job_description = opisView.Text;
                    DatabaseControl.AddJob(new job
                    {
                        title_job = jobView.Text,
                        job_description = opisView.Text,
                    });
                    daf.Content = new NewFolder1.JobWork();
                }
            }
            catch
            {
                MessageBox.Show("Неверный формат дынных", "Ошибка при вводе", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
