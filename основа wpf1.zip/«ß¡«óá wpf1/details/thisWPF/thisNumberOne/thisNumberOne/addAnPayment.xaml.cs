﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для addAnPayment.xaml
    /// </summary>
    public partial class addAnPayment : Page
    {
        public addAnPayment()
        {
            InitializeComponent();
        }

        //Кнопка отмены
        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        //Кнопка сохранить
        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            if(fioView != null)
            {
                MessageBox.Show("Выберите элемент для изменения", "Ошибка при выборе объекта", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                payment _tempPayment = new payment();
                _tempPayment.payment_methods = fioView.Text;
                DatabaseControl.AddPayment(new payment
                {
                    payment_methods = fioView.Text,
                });
                daf.Content = new NewFolder1.ListPayment();
            }
            //if(fioView.Text != null)
            //{
            //    payment _tempPayment = new payment();
            //    _tempPayment.payment_methods = fioView.Text;
            //    DatabaseControl.AddPayment(new payment
            //    {
            //        payment_methods = fioView.Text,
            //    });
            //    daf.Content = new NewFolder1.ListPayment();
            //}else
            //{
            //    MessageBox.Show("Выберите элемент для изменения", "Ошибка при выборе объекта", MessageBoxButton.OK, MessageBoxImage.Error);
            //}
        }


        //Сохранение при нажатии кнопки Enter
        private void fioView_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.Key == Key.Return)
            {
                payment _tempPayment = new payment();
                _tempPayment.payment_methods = fioView.Text;
                DatabaseControl.AddPayment(new payment
                {
                    payment_methods = fioView.Text,
                });
                daf.Content = new NewFolder1.ListPayment();
            }
        }
    }
}
