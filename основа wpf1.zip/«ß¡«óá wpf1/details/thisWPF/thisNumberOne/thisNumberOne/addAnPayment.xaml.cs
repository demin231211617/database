﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для addAnPayment.xaml
    /// </summary>
    public partial class addAnPayment : Page
    {
        public addAnPayment()
        {
            InitializeComponent();
        }

        private void Pluse1_Click(object sender, RoutedEventArgs e)
        {
            this.Content = null;
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            payment _tempPayment = new payment();
            _tempPayment.payment_methods = fioView.Text;
            DatabaseControl.AddPayment(new payment
            {
                payment_methods = fioView.Text,
            });
            daf.Content = new AdditionalInformation();
        }
    }
}
