﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace thisNumberOne
{
    public class DatabaseControl
    {
        //Клиент
        public static List<client> GetPhonesForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.client.ToList();
            }
        }

        public static void AddClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.client.Add(client);
                ctx.SaveChanges();
            }
        }

        public static void DelClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.client.Remove(client);
                ctx.SaveChanges();
            }
        }

        public static void UpdateClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                client _client = ctx.client.FirstOrDefault(p => p.client_id == client.client_id);

                if (_client == null)
                {
                    return;
                }

                _client.client_id = client.client_id;
                _client.client_fio = client.client_fio;
                _client.client_phone = client.client_phone;
                _client.client_adress = client.client_adress;

                ctx.SaveChanges();
            }
        }

        //Поставщики
        public static List<suppliers> GetSuppliersForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.suppliers.ToList();
            }
        }

        public static void AddClientSuppliers(suppliers suppliers)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.suppliers.Add(suppliers);
                ctx.SaveChanges();
            }
        }

        public static void DelSuppliers(suppliers suppliers)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.suppliers.Remove(suppliers);
                ctx.SaveChanges();
            }
        }

        public static void UpdateClientsuppliers(suppliers suppliers)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                suppliers _suppliers = ctx.suppliers.FirstOrDefault(p => p.suppliers_id == suppliers.suppliers_id);

                _suppliers.suppliers_id = suppliers.suppliers_id;
                _suppliers.suppliers_phone = suppliers.suppliers_phone;
                _suppliers.suppliers_title = suppliers.suppliers_title;
                _suppliers.suppliers_adress = suppliers.suppliers_adress;

                ctx.SaveChanges();
            }
        }

        //Должность
        public static List<job> GetJobForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.job.ToList();
            }
        }

        public static void AddJob(job job)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.job.Add(job);
                ctx.SaveChanges();
            }
        }

        public static void DelJob(job job)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.job.Remove(job);
                ctx.SaveChanges();
            }
        }

        public static void UpdateJob(job job)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                job _job = ctx.job.FirstOrDefault(p => p.job_id == job.job_id);

                if (_job == null)
                {
                    return;
                }

                _job.title_job = job.title_job;
                _job.job_description = job.job_description;

                ctx.SaveChanges();
            }
        }

        //Сотрудник
        public static List<employee_db> GetEmployeeForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.employee_db.ToList();
            }
        }

        public static void AddEmployee(employee_db employee_db)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.employee_db.Add(employee_db);
                ctx.SaveChanges();
            }
        }

        public static void DelEmployee(employee_db employee_db)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.employee_db.Remove(employee_db);
                ctx.SaveChanges();
            }
        }

        public static void UpdateEmployee(employee_db employee_db)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                employee_db _employee_db = ctx.employee_db.FirstOrDefault(p => p.employee_id == employee_db.employee_id);

                if (_employee_db == null)
                {
                    return;
                }

                _employee_db.employee_fio = employee_db.employee_fio;
                _employee_db.serial_number = employee_db.serial_number;
                _employee_db.date_of_issue = employee_db.date_of_issue;
                _employee_db.division_code = employee_db.division_code;
                _employee_db.employee_phone = employee_db.employee_phone;
                _employee_db.employee_adress = employee_db.employee_adress;
                _employee_db.employee_job_title = employee_db.employee_job_title;
                _employee_db.employee_wage = employee_db.employee_wage;
                _employee_db.login = employee_db.login;
                _employee_db.password_employee = employee_db.password_employee;
                _employee_db.serial_employee = employee_db.serial_employee;

                ctx.SaveChanges();
            }
        }
    }
}
