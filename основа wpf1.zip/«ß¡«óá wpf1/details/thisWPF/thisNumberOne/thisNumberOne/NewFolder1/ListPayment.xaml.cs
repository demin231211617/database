﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne.NewFolder1
{
    /// <summary>
    /// Логика взаимодействия для ListPayment.xaml
    /// </summary>
    public partial class ListPayment : Page
    {
        public ListPayment()
        {
            InitializeComponent();
            JobWork1.ItemsSource = DatabaseControl.GetPaymentForView();
        }

        private void editButtonPayment_Click(object sender, RoutedEventArgs e)
        {
            payment p = JobWork1.SelectedItem as payment;
            if (p != null)
            {
                ret.Content = new editAnPayment(p);
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления", "Ошибка при удалении объекта", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void removeButtonPAyment_Click(object sender, RoutedEventArgs e)
        {
            payment p = JobWork1.SelectedItem as payment;
            if (p != null)
            {
                DatabaseControl.DelPayment(JobWork1.SelectedItem as payment);
                JobWork1.ItemsSource = null;
                JobWork1.ItemsSource = DatabaseControl.GetPaymentForView();
            }
            else
                MessageBox.Show("Выберите элемент для удаления", "Ошибка при удалении объекта", MessageBoxButton.OK, MessageBoxImage.Error);
        }

        private void PlusePayment_Click(object sender, RoutedEventArgs e)
        {
            ret.Content = new addAnPayment();
        }
    }
}
