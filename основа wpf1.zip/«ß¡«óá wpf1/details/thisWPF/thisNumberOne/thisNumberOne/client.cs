﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class client
    {
        [Key] public int client_id { get; set; }
        public string client_fio { get; set; }
        public string client_phone { get; set; }
        public string client_adress { get; set; }
    }
}
