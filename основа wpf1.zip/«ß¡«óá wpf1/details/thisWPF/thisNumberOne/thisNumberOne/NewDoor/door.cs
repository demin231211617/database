﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using thisNumberOne.FolderGlassColor;

namespace thisNumberOne.NewDoor
{
    public class door
    {
        [Key] public int door_id { get; set; }
        public string door_title { get; set; }
        public string door_model { get; set; }
        public int door_cost { get; set; }
        public int number_ofdoors { get; set; }
        public string vendor_code_door { get; set; }
        [ForeignKey("doorColorEnity")]public int door_color { get; set; }
        [ForeignKey("glassColorEnity")]public int door_glass { get; set; }
        public door_color doorColorEnity{get; set;}
        public glass_color glassColorEntity { get; set; }
    }
}
