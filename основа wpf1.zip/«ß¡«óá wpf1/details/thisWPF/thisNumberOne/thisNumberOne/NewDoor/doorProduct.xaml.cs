﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne.NewDoor
{
    /// <summary>
    /// Логика взаимодействия для doorProduct.xaml
    /// </summary>
    public partial class doorProduct : Page
    {
        public doorProduct()
        {
            InitializeComponent();
            doors.ItemsSource = DatabaseControl.GetDoorList();
        }

        private void Pluse_Click(object sender, RoutedEventArgs e)
        {
            //
        }

        private void editButton_Click(object sender, RoutedEventArgs e)
        {
            door door = doors.SelectedItem as door;
            if(door != null)
            {
                //
            }
            else
            {
                MessageBox.Show("Выберите элемент для изменения");
            }
        }

        private void removeButton_Click(object sender, RoutedEventArgs e)
        {
            door door = doors.SelectedItem as door;
            if(door != null)
            {
                DatabaseControl.DelDoor(doors.SelectedItem as door);
                doors.ItemsSource = null;
                ret.Content = new doorProduct();
            }
            else
            {
                MessageBox.Show("Выберите элемент для удаления");
            }
        }
    }
}
