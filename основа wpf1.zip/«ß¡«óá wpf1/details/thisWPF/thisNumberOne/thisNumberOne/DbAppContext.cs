﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class DbAppContext : DbContext
    {
        public DbSet<client> client { get; set; }
        public DbSet<suppliers> suppliers { get; set; }
        public DbSet<job> job { get; set; }
        public DbSet<employee_db> employee_db { get; set; } 
        public DbSet<payment> payment { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(
                "Host=localhost;Username=postgres;Password=22345621;Database=BellaPorta");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<employee_db>().HasOne(p => p.jobEntity).WithMany(p => p.employeeEntities);
        }
    }
}
