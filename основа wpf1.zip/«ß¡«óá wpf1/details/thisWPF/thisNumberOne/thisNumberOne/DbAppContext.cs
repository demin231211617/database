﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using thisNumberOne.FolderGlassColor;
using thisNumberOne.FolderPenColor;

namespace thisNumberOne
{
    public class DbAppContext : DbContext
    {
        public DbSet<client> client { get; set; }
        public DbSet<suppliers> suppliers { get; set; }
        public DbSet<job> job { get; set; }
        public DbSet<employee_db> employee_db { get; set; } 
        public DbSet<payment> payment { get; set; }
        public DbSet<door_color> door_color { get; set; }
        public DbSet<pen_color> pen_color { get; set; }
        public DbSet<glass_color> glass_color { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseNpgsql(
                "Host=localhost;Username=postgres;Password=root;Database=bellaPorta");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<employee_db>().HasOne(p => p.jobEntity).WithMany(p => p.employeeEntities);
        }
    }
}
