﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;


namespace thisNumberOne
{
    public class employee_db
    {
        [Key] public int employee_id { get; set; }
        public string employee_fio { get; set; }
        public string serial_number { get; set; }
        public DateTime date_of_issue { get; set; }
        public string division_code { get; set; }
        public string employee_phone { get; set; }
        public string employee_adress { get; set; }
        public string employee_job_title { get; set; }
        public int employee_wage { get; set; }
        public string login { get; set; }
        public string password_employee { get; set; }
        public string serial_employee { get; set; }
    }
}
