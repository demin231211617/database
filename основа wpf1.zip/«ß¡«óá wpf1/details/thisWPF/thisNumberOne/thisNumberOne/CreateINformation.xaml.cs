﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для CreateINformation.xaml
    /// </summary>
    public partial class CreateINformation : Page
    {
        public CreateINformation()
        {
            InitializeComponent();
        }

        private void sad_Click(object sender, RoutedEventArgs e)
        {
            Red.Content = new NewFolder1.JobWork();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Red.Content = new NewFolder1.ListPayment();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void Red_Navigated(object sender, NavigationEventArgs e)
        {

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Red.Content = new NewFolder1.DoorColor();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            Red.Content = new FolderPenColor.penColor();
        }

        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            Red.Content = new FolderGlassColor.glassColor();
        }
    }
}
