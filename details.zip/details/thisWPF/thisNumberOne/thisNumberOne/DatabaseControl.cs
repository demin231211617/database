﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace thisNumberOne
{
    public class DatabaseControl
    {
        public static List<client> GetPhonesForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.client.ToList();
            }
        }

        public static void AddClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.client.Add(client);
                ctx.SaveChanges();
            }
        }

        public static void UpdateClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                client _client = ctx.client.FirstOrDefault(p => p.clientid == client.clientid);

                _client.clientfio = client.clientfio;
                _client.clientphone = client.clientphone;
                _client.dateofbirth = client.dateofbirth;
                _client.clientadress = client.clientadress;

                ctx.SaveChanges();
            }
        }

        public static List<suppliers> GetSuppliersForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.suppliers.ToList();
            }
        }

        public static void AddClientSuppliers(suppliers suppliers)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.suppliers.Add(suppliers);
                ctx.SaveChanges();
            }
        }

        public static void UpdateClientsuppliers(suppliers suppliers)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                suppliers _suppliers = ctx.suppliers.FirstOrDefault(p => p.suppliersid == suppliers.suppliersid);

                _suppliers.suppliersid = suppliers.suppliersid;
                _suppliers.suppliersphone = suppliers.suppliersphone;
                _suppliers.supplierstitle = suppliers.supplierstitle;
                _suppliers.suppliersadress = suppliers.suppliersadress;

                ctx.SaveChanges();
            }
        }
    }
}
