﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class suppliers
    {
        public int suppliersid { get; set; }
        public string supplierstitle { get; set; }
        public string suppliersadress { get; set; }
        public string suppliersphone { get; set; }
    }
}
