﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class client
    {
        [Key] public int clientid { get; set; }
        public string clientfio { get; set; }
        public string clientphone { get; set; }
        public string clientadress { get; set; }
        public DateTime dateofbirth { get; set; }
    }
}
