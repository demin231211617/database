﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class DbPen
    {
        public int penId { get; set; }
        public string penTitle { get; set; }
        public string penModel { get; set; }
        public int penCost { get; set; }
        public int penArticleNumber { get; set; }
        public int penQuantity { get; set; }
        public string penSuppliers { get; set; }
        public string penColor { get; set; }
    }
}
