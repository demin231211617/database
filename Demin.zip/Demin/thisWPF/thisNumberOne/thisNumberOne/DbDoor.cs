﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class DbDoor
    {
        public int doorId { get; set; }
        public string doorTitle { get; set; }
        public string doorModel { get; set; }
        public int doorCost { get; set; }
        public int doorArticleNumber { get; set; }
        public int doorQuantity { get; set; }
        public string doorSuppliers { get; set; }
        public string doorColor { get; set; }
    }
}
