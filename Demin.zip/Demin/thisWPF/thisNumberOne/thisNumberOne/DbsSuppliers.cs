﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class DbsSuppliers
    {
        public int suppliersId { get; set; }
        public string suppliersTitle { get; set; }
        public string suppliersAdress { get; set; }
        public string deliveryDate { get; set; }
        public int deliveryCost { get; set; }
        public string supplierstPhone { get; set; }
    }
}
