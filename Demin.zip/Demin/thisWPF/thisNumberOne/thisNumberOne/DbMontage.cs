﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class DbMontage
    {
        public int montageId {  get; set; }
        public string dateMontage { get; set; }
        public string timeMontage { get; set; }
        public string fitter { get; set; }
        public int montageCost { get; set; }
    }
}
