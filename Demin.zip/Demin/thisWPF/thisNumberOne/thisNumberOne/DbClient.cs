﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class DbClient
    {
        public int clientId { get; set; }
        public string clientFIO { get; set; }
        public string clientPhone { get; set; }
        public string clientAdress { get; set; }
    }
}
