﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class DbEmployee
    {
        public int Id { get; set; }
        public string image {get; set; } 
        public string employeeFIO { get; set; }
        public string sideNumber { get; set; }
        public string dateOfIssue { get; set; }
        public int departmentCode { get; set; }
        public string employeePhone { get; set; }
        public string employeeAdress { get; set; }
        public string jobTitle { get; set; }
        public int wage { get; set; }
        public string employeeLogin { get; set; }
        public string employeePassword { get; set; }
        public string serialNumber { get; set; }
    }
}
