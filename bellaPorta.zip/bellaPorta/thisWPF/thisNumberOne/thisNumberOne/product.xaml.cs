﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace thisNumberOne
{
    /// <summary>
    /// Логика взаимодействия для product.xaml
    /// </summary>
    public partial class product : Page
    {
        public product()
        {
            InitializeComponent();
        }

        private void doorButton_Click(object sender, RoutedEventArgs e)
        {
            plusProduct.Visibility= Visibility.Visible;
            plusServes.Visibility= Visibility.Hidden;
            plusmontage.Visibility= Visibility.Hidden;
            plusmeasuring.Visibility= Visibility.Hidden;

            ListOfProduct.Content = new ListProduct();
        }

        private void penButton_Click(object sender, RoutedEventArgs e)
        {
            plusProduct.Visibility = Visibility.Hidden;
            plusServes.Visibility = Visibility.Visible;
            plusmontage.Visibility = Visibility.Hidden;
            plusmeasuring.Visibility = Visibility.Hidden;

            ListOfProduct.Content = new PenProduct();
        }

        private void montageButton_Click(object sender, RoutedEventArgs e)
        {
            plusProduct.Visibility = Visibility.Hidden;
            plusServes.Visibility = Visibility.Hidden;
            plusmontage.Visibility = Visibility.Visible;
            plusmeasuring.Visibility = Visibility.Hidden;
        }

        private void measuringButton_Click(object sender, RoutedEventArgs e)
        {
            plusProduct.Visibility = Visibility.Hidden;
            plusServes.Visibility = Visibility.Hidden;
            plusmontage.Visibility = Visibility.Hidden;
            plusmeasuring.Visibility = Visibility.Visible;
        }

        private void HomeProduct_Click(object sender, RoutedEventArgs e)
        {
            plusProduct.Visibility = Visibility.Hidden;
            plusServes.Visibility = Visibility.Hidden;
            plusmontage.Visibility = Visibility.Hidden;
            plusmeasuring.Visibility = Visibility.Hidden;

            ListOfProduct.Content = null;
        }
    }
}
