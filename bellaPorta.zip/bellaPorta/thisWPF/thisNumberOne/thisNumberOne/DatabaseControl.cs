﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public static class DatabaseControl
    {
        public static List<client> GetClientForView()
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                return ctx.client.ToList();
            }
        }

        public static void AddClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                ctx.client.Add(client);
                ctx.SaveChanges();
            }
        }

        public static void UpdateClient(client client)
        {
            using (DbAppContext ctx = new DbAppContext())
            {
                client _client = ctx.client.FirstOrDefault(p => p.client_id == client.client_id);

                _client.client_fio = client.client_fio;
                _client.client_adress = client.client_adress;
                _client.client_adress = _client.client_adress;
                _client.date_of_birth = client.date_of_birth;
            }
        }
    }
}
