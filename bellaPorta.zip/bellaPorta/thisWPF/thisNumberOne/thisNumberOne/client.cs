﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace thisNumberOne
{
    public class client
    {
        public int client_id { get; set; }
        public string client_fio { get; set; }
        public string client_phone { get; set; }
        public string client_adress { get; set; }
        public string date_of_birth { get; set; }
    }
}
