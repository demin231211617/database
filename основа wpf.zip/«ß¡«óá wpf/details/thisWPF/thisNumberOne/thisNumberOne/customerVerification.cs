﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace thisNumberOne
{
    public class customerVerification
    {
        //проверка для клиента
        static public bool CheckEmpty(string client_fio, string client_phone, string client_adress)
        {
            if((client_fio == "") || (client_phone == "") || (client_adress == ""))
            {
                MessageBox.Show("Строки не должны быть пустыми!", "Неверный ввод", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            return true;
        }

        //проверка для поставщиков
        static public bool CheckEmptySupp(string suppliers_title, string suppliers_adress, string suppliers_phone)
        {
            if((suppliers_title == "") || (suppliers_adress == "") || (suppliers_phone  == ""))
            {
                MessageBox.Show("Строки не должны быть пустыми!", "Неверный ввод", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
            return true;
        }
    }
}
